/*Create a JAVA program to split the strings based on white-spaces, after the
split operation, print all the strings in the dictionary order.*/


package string;

public class prog4_dictionary {
	public static void main(String[] args) {
		String s="This program gives smallest string ";
		String[] s1 = new String[10];
		String temp;
		int j=0,a1=0,l=100;
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)==' ')
			{
				s1[j]=s.substring(a1, i);
				j++;
				a1=i+1;
			
			}
		}
		for(int i=0;i<j;i++)
			System.out.println(s1[i]);
		for(int k=0;k<j;k++)
			for(int i=0;i<j-1;i++)
			{
				if(s1[i].compareToIgnoreCase(s1[i+1])>0)
				{
					temp=s1[i];
					s1[i]=s1[i+1];
					s1[i+1]=temp;
				}
			}
		System.out.println("Strings in dictionary order is :");
		for(int i=0;i<j;i++)
			System.out.println(s1[i]);
	}
}

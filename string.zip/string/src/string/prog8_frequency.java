/*Create a JAVA program to find the maximum and minimum occurred
character in a String*/
package string;

public class prog8_frequency {
	public static void main(String args[])
	{
		String s="javaprogramming";
		
		char[] a=new char[100],b=new char[10];
		char t;
		int[] n=new int[10];
		int c=0,min=0,max=0,mini=0,maxi=0;
		a=s.toCharArray();
		for(int i=0;i<s.length();i++)       //sorting
			for(int j=i+1;j<s.length();j++)
				if(a[i]>a[j])
				{
					t=a[i];
					a[i]=a[j];
					a[j]=t;
				}
		System.out.println(a);
		for(int i=1;i<a.length-1;i++)         //finding frequency and storing in array
		{
			if(a[i]==a[i-1])
			{
				n[c]++;
			}
			else
			{	
				c++;
				a[c]=a[i];
			}
		}
		max=n[0];min=n[0];
		for(int i=0;i<=c;i++)
		{
			if(n[i]>max)
			{
				max=n[i];maxi=i;
			}
		}
		for(int i=0;i<=c;i++)
		{
				if(n[i]<min)
				{
					min=n[i];mini=i;
					
				}
		}
		System.out.println("Maximum occurred character is :"+a[maxi]);
		System.out.println("Minimum occurred character is :"+a[mini]);
	}
}


/*Toggle the strings using JAVA. Toggling is the process of converting the
uppercase characters to lower case and vice versa.*/

package string;

public class prog5_toggling {
	public static void main(String[] args)
		{
		String T="lowerUPPERcase",s="";
		int i=0;
		for(i=0;i<T.length();i++)
		if(Character.isUpperCase(T.charAt(i)))
			s+=Character.toLowerCase(T.charAt(i));
		else if(Character.isLowerCase(T.charAt(i)))
			s+=Character.toUpperCase(T.charAt(i));
		System.out.println(s);
		}
}

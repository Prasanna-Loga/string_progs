/*Create a JAVA program to merge two given strings S1 and S2. Perform
merge operation by taking single character from each string.
Example: If the string S1 = �ABC�, S2= �DEF�, Output: ADBECF.*/

package string;

public class prog7_merge {
	public static void main(String args[]) {
		String S1="ABC",S2="DEF",S3="";
		int l=0;
		if(S1.length()>S2.length())//to determine length for loop
			l=S1.length();
		else
			l=S2.length();
		for(int i=0;i<l;i++)
		{
			if(S1.length()>i)//to neglect index out of bound exception when string length differs
				S3+=S1.charAt(i);
			if(S2.length()>i)
				S3+=S2.charAt(i);
		}
		System.out.println(S3);
	}
}

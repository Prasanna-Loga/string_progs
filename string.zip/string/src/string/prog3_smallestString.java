/*Create a JAVA program to split the strings based on the white-spaces, after
the split operation, print the string with the smallest length. */


package string;

public class prog3_smallestString {
public static void main(String[] args) {
	String s="This program gives smallest string ";
	String[] s1 = new String[10];
	String smallest = null;
	int j=0,a1=0,l=100;
	for(int i=0;i<s.length();i++)
	{
		if(s.charAt(i)==' ')
		{
			s1[j]=s.substring(a1, i);
			j++;
			a1=i+1;
		
		}
			
	}
	for(int i=0;i<j;i++)
		System.out.println(s1[i]);
	for(int i=0;i<j;i++)
	{
		if(s1[i].length()<l)
		{
			l=s1[i].length();
			smallest=s1[i];
		}
	}
	System.out.println("The smallest string in the given sentence is "+smallest);
}
}

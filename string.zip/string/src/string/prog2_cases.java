/*Write a JAVA program to count the total upper-case and lower-case
characters of a String T. After counting, print them if and only if the count is
not equal. If the count is equal, print �Equally Distributed�*/

package string;

public class prog2_cases {
	public static void main(String[] args) {
		String T="lowerUPPERcase";
		int n1=0,n2=0;
		char[] a=T.toCharArray();
		for(int i=T.length()-1;i>=0;i--)
		{
			if(Character.isUpperCase(a[i]))
					n1++;
			if(Character.isLowerCase(a[i]))
					n2++;
		}
		if(n1==n2)
			System.out.println("Equally Distributed");
		else
		{
			System.out.println("Count of uppercase is "+n1);
			System.out.println("Count of lowercase is "+n2);
		}
	}

}

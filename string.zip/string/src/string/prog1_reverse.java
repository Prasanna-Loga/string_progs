
/*Write a JAVA program to reverse the given String S. Perform the reversal
operation if and only if the string S is equivalent to S1 are equal. (Perform
case-sensitive comparison). If the strings are not equal print �Reverse Not
Supported�.
Example: String S = �Hari�, S1 = �Wipro�, output should be �Reverse Not
Supported�.*/




package string;

public class prog1_reverse {
	public static String reverse(String s) {
		char[] a=s.toCharArray();
		String s2="";
		for(int i=s.length()-1;i>=0;i--)
			s2=s2+a[i];
		return s2;
	}
	public static void main(String[] args) {
		String s="Hari",s1="Wipro";
		if(s.equals(s1))
			System.out.println(reverse(s));
		else
			System.out.println("Reverse Not Supported");
	}

	
}

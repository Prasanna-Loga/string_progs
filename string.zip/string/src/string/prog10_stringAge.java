/*Write a JAVA program to compute the string age. Age of the string can be
calculated using the formula:
Age = Length of the string S + Alphabetical index of the last-character.
Example: If the string is �ABAB�, output = (4+2) = 6*/

package string;

public class prog10_stringAge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="ABAB";
		int a=s.charAt(s.length()-1);
		if(a>96)
			a-=96;
		else
			a-=64;
		System.out.println("Age of the string is "+(s.length()+a));
	}

}

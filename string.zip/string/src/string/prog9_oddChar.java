/*Create a JAVA program to sort the characters of the string S. After sorting,
extract the odd-positioned characters and store it into a string variable and
print it.*/

package string;

public class prog9_oddChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="programming";
		char[] a=new char[10];
		char t;
		a=s.toCharArray();
		for(int i=0;i<s.length();i++)
			for(int j=i+1;j<s.length();j++)
				if(a[i]>a[j])
				{
					t=a[i];
					a[i]=a[j];
					a[j]=t;
				}
		System.out.println(a);
		for(int i=0;i<s.length();i=i+2)
	System.out.print(a[i]);
	}
}

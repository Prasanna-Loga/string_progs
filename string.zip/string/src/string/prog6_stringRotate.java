/*Create a JAVA program to rotate the string by clock-wise direction if the
length is even and to rotate the string to the anti-clockwise direction if the
length is odd. Perform one rotation at any case.*/

package string;

import java.util.Scanner;

public class prog6_stringRotate {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.next();
		char c;
		if(s.length()%2==0)
		{
			c=s.charAt(0);
			s=s.substring(1)+c;
		}
		else
		{
			c=s.charAt(s.length()-1);
			s=c+s.substring(0, s.length()-1);
		}
		System.out.println(s);
	}
}
